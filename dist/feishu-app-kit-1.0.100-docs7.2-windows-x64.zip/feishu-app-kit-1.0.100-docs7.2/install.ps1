[CmdletBinding()]
param(
    [string]$BinDir = '',
    [string]$SkillsDir = '',
    [switch]$AddToPath,
    [switch]$ReplaceSharedSkill,
    [switch]$VerifyOnly
)

$ErrorActionPreference = 'Stop'
$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
$userRoot = [Environment]::GetFolderPath('UserProfile')
if (-not $BinDir) { $BinDir = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'FeishuAppKit\bin' }
if (-not $SkillsDir) {
    if ($env:CODEX_HOME) { $SkillsDir = Join-Path $env:CODEX_HOME 'skills' }
    else { $SkillsDir = Join-Path $userRoot '.codex\skills' }
}
$binRoot = [IO.Path]::GetFullPath($BinDir).TrimEnd([IO.Path]::DirectorySeparatorChar)
$skillsRoot = [IO.Path]::GetFullPath($SkillsDir).TrimEnd([IO.Path]::DirectorySeparatorChar)

function Assert-ChildPath([string]$Root, [string]$Child) {
    $prefix = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath($Child)
    if (-not $full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Path is outside the selected directory: $full" }
    return $full
}

function Get-SHA256([string]$Path) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}

function Verify-Package {
    $count = 0
    foreach ($line in Get-Content -LiteralPath (Join-Path $packageRoot 'SHA256SUMS')) {
        if (-not $line) { continue }
        if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw 'Invalid checksum manifest.' }
        $expected = $Matches[1]
        $relative = $Matches[2]
        if ([IO.Path]::IsPathRooted($relative)) { throw 'Absolute manifest path is not allowed.' }
        $file = Assert-ChildPath $packageRoot (Join-Path $packageRoot $relative)
        $item = Get-Item -LiteralPath $file -Force
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Expected a regular package file: $relative" }
        if ((Get-SHA256 $file) -ne $expected) { throw "Checksum mismatch: $relative" }
        $count++
    }
    if ($count -lt 10) { throw 'Incomplete package manifest.' }
    Write-Host "Verified $count package files."
}

function Run-LocalCheck([string]$Executable, [string]$Arguments, [string]$ConfigDir) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $Executable
    $start.Arguments = $Arguments
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($key in @($start.EnvironmentVariables.Keys)) {
        if ($key -like 'LARKSUITE_CLI_*' -or $key -in @('HERMES_HOME', 'OPENCLAW_HOME')) { $start.EnvironmentVariables.Remove($key) }
    }
    $start.EnvironmentVariables['LARKSUITE_CLI_CONFIG_DIR'] = $ConfigDir
    $start.EnvironmentVariables['LARKSUITE_CLI_LOG_DIR'] = (Join-Path $ConfigDir 'logs')
    $start.EnvironmentVariables['LARKSUITE_CLI_NO_UPDATE_NOTIFIER'] = '1'
    $start.EnvironmentVariables['LARKSUITE_CLI_NO_SKILLS_NOTIFIER'] = '1'
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $start
    try {
        [void]$process.Start()
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(30000)) { $process.Kill(); throw 'CLI check timed out.' }
        $stdout = $stdoutTask.Result
        $stderr = $stderrTask.Result
        if ($process.ExitCode -ne 0) { throw "CLI check failed: $stderr" }
        return $stdout
    } finally { $process.Dispose() }
}

Verify-Package
if ($VerifyOnly) { return }

$machine = $env:PROCESSOR_ARCHITECTURE
if ($env:PROCESSOR_ARCHITEW6432) { $machine = $env:PROCESSOR_ARCHITEW6432 }
switch ($machine.ToUpperInvariant()) {
    'AMD64' { $architecture = 'amd64' }
    'ARM64' { $architecture = 'arm64' }
    default { throw "This kit supports Windows x64/ARM64; detected $machine." }
}
$sourceBinary = Join-Path $packageRoot "bin\windows-$architecture\lark-cli.exe"
$sourceExport = Join-Path $packageRoot "bin\windows-$architecture\feishu-credential-export.exe"
if (-not (Test-Path -LiteralPath $sourceBinary -PathType Leaf) -or -not (Test-Path -LiteralPath $sourceExport -PathType Leaf)) { throw 'A matching binary is missing.' }
New-Item -ItemType Directory -Path $binRoot -Force | Out-Null
New-Item -ItemType Directory -Path $skillsRoot -Force | Out-Null
$stamp = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
$backupRoot = Assert-ChildPath $binRoot (Join-Path $binRoot ('backups\' + $stamp))
$destination = Assert-ChildPath $binRoot (Join-Path $binRoot 'lark-cli.exe')
$exportDestination = Assert-ChildPath $binRoot (Join-Path $binRoot 'feishu-credential-export.exe')
foreach ($binary in @(@{Source=$sourceBinary; Destination=$destination}, @{Source=$sourceExport; Destination=$exportDestination})) {
    if (Test-Path -LiteralPath $binary.Destination) {
        $existing = Get-Item -LiteralPath $binary.Destination -Force
        if ($existing.PSIsContainer -or ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Existing executable is not a regular file.' }
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        Copy-Item -LiteralPath $binary.Destination -Destination (Join-Path $backupRoot $existing.Name)
    }
    Copy-Item -LiteralPath $binary.Source -Destination $binary.Destination -Force
}

foreach ($name in @('feishu-enterprise-app-setup', 'lark-shared')) {
    $sourceSkill = Join-Path $packageRoot ('skills\' + $name)
    $targetSkill = Assert-ChildPath $skillsRoot (Join-Path $skillsRoot $name)
    if (Test-Path -LiteralPath $targetSkill) {
        $existing = Get-Item -LiteralPath $targetSkill -Force
        if ($name -eq 'lark-shared' -and -not $ReplaceSharedSkill) {
            if (-not $existing.PSIsContainer) { throw 'Existing lark-shared is not a skill directory.' }
            Write-Host 'Keeping the existing lark-shared skill.'
            continue
        }
        if (-not $existing.PSIsContainer -or ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Existing skill path is not a regular directory: $name" }
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        Copy-Item -LiteralPath $targetSkill -Destination (Join-Path $backupRoot $name) -Recurse
    } else { New-Item -ItemType Directory -Path $targetSkill -Force | Out-Null }
    foreach ($entry in Get-ChildItem -LiteralPath $sourceSkill -Force) {
        Copy-Item -LiteralPath $entry.FullName -Destination $targetSkill -Recurse -Force
    }
}

$checkDir = Assert-ChildPath $binRoot (Join-Path $binRoot ('.check-' + [Guid]::NewGuid().ToString('N')))
$version = (Run-LocalCheck $destination '--version' $checkDir).Trim()
if ($version -ne 'lark-cli version 1.0.100-docs7.2') { throw "Unexpected installed version: $version" }
[void](Run-LocalCheck $exportDestination '--help' $checkDir)
$plan = Run-LocalCheck $destination 'config init --new --dry-run' $checkDir | ConvertFrom-Json
$expectedScopes = @('docs:document.content:read','docs:document.media:download','docx:document:readonly','drive:drive:readonly','offline_access','space:document:retrieve','wiki:wiki:readonly')
if ($plan.permission_preset -ne 'docs7-managed' -or $plan.addons.preset -ne $false -or $plan.create_only -ne $true) { throw 'Unexpected permission preset.' }
if (@($plan.addons.scopes.user).Count -ne 7 -or @(Compare-Object $expectedScopes @($plan.addons.scopes.user)).Count -ne 0) { throw 'Unexpected user scopes.' }
if (@($plan.addons.scopes.tenant).Count -ne 1 -or $plan.addons.scopes.tenant[0] -ne 'application:application:patch') { throw 'Unexpected tenant scope.' }
if (Test-Path -LiteralPath (Join-Path $checkDir 'config.json')) { throw 'The dry-run unexpectedly wrote an app binding.' }

if ($AddToPath) {
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $entries = @($userPath -split ';' | Where-Object { $_ })
    if ($entries -notcontains $binRoot) {
        [Environment]::SetEnvironmentVariable('Path', ($binRoot + ';' + $userPath), 'User')
    }
    $env:Path = $binRoot + ';' + $env:Path
    Write-Host 'User PATH updated. Restart other terminals and your agent app to pick it up.'
}
Write-Host $version
Write-Host "CLI: $destination"
Write-Host "Credential export: $exportDestination"
Write-Host "Skills: $skillsRoot"
if (Test-Path -LiteralPath $backupRoot) { Write-Host "Previous files backed up: $backupRoot" }
Write-Host 'Install checks passed. No app was created and no account was authorized.'
if (-not $AddToPath) { Write-Host 'Use the full CLI path above, or rerun with -AddToPath.' }
